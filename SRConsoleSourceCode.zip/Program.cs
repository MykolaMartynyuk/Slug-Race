﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Timers;

namespace SlugRace
{
    public class Program
    {
        public static int money;
        public static int bet = 0;
        public static int slag;
        public static int winner = 3;
        public static int record = 500;
        public static string finnish = "||";
        public static bool musicOn = true;
        public static bool soundOn = true;
        public static bool toExit = false;
        public static Random rnd = new Random();
        public static List<string> drawslagMidle = new List<string>() { " ___ o|o", "/@@@\\/^ ", "*****   " };
        public static List<string> drawslagBeginning = new List<string>();
        public static List<string> drawslagEnd = new List<string>() { " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", String.Empty };
        public static ConsoleColor[] colors = (ConsoleColor[])ConsoleColor.GetValues(typeof(ConsoleColor)); // source https://docs.microsoft.com/en-us/dotnet/api/system.consolecolor?view=net-6.0
        public static string save = @"save.txt";
        public static string saveM = @"saveM.txt";
        public static SoundPlayer sMusic = new SoundPlayer(@"sound\slagmove.wav");
        public static SoundPlayer bMusic = new SoundPlayer(@"sound\backgroundmusic.wav");
        public static System.Timers.Timer timer = new System.Timers.Timer(); //https://stackoverflow.com/questions/12535722/what-is-the-best-way-to-implement-a-timer
        // externe bronnen Google.com en Stackoverflow.com en officiële .NET-documentatie op de microsoft-site

        public static void Main(string[] args)
        {


            timer.Elapsed += new ElapsedEventHandler(PlayBMusic);//https://stackoverflow.com/questions/12535722/what-is-the-best-way-to-implement-a-timer
            timer.Interval = 14500;//https://stackoverflow.com/questions/12535722/what-is-the-best-way-to-implement-a-timer
            if (musicOn == true)
            {
                timer.Start();
            }
            if (!File.Exists(save))
            {
                File.Create(save);
            }
            if (!File.Exists(saveM))
            {
                File.Create(saveM);
            }
            StreamReader sr = File.OpenText(saveM);
            string s;
            while ((s = sr.ReadLine()) != null)
            {
                money = Convert.ToInt32(s);
                sr.ReadToEnd();
                break;
            }
            sr.Close();
            if (money == 0) { money = 500; }
            bMusic.Play();
            MainMenu();
        }

        private static void MainMenu()
        {
            Console.Clear();
            Console.WriteLine("SlagRace 3000");
            Console.WriteLine("=============");
            Console.WriteLine();
            Console.WriteLine("    ___ o|o");
            Console.WriteLine("   /@@@\\/^");
            Console.WriteLine("   *****");
            Console.WriteLine("");
            Console.WriteLine("1. Begin het spel");
            Console.WriteLine("2. Opties");
            Console.WriteLine("3. Scorebord");
            Console.WriteLine("4. Afsluiten");
            int i = CheckConsole(1, 4);
            if (i == 1)
            {
                Weddenschap();
            }
            else if (i == 2)
            {
                Option();
            }
            else if (i == 4)
            {
                Exit();
            }
            else if (i == 3)
            {
                LeaderBord();
            }

        }

        private static void Option()
        {
            Console.WriteLine("Opties:");
            Console.WriteLine("1. Muziek in-/uitschakelen");
            Console.WriteLine("2. Zet het geluid van het spel aan/uit");
            Console.WriteLine("3. Terug naar menu");
            int i = CheckConsole(1, 3);
            if (i == 1)
            {
                Console.Write("Muziek 1.Inschakelen 2.uitschakelen");
                int j = CheckConsole(1, 2);
                if (j == 1)
                {
                    musicOn = true;
                    bMusic.Play();
                    timer.Start();

                }
                else if (j == 2)
                {
                    musicOn = false;
                    timer.Stop();
                    bMusic.Stop();
                }
                Option();
            }
            if (i == 2)
            {
                Console.Write("Geluid 1.aan 2.uit");
                int k = CheckConsole(1, 2);
                if (k == 1)
                {
                    soundOn = true;
                }
                if (k == 2)
                {
                    soundOn = false;
                }
                Option();
            }
            if (i == 3)
            {
                MainMenu();
            }

        }

        private static void Exit()
        {
            toExit = true;
            Save();
            return;
        }

        private static void Weddenschap()
        {

            Console.WriteLine("Plaats je weddenschap!");
            Console.WriteLine("Geld op de rekening: " + money);
            Console.WriteLine("Welke slak zal winnen?");
            Console.WriteLine("1.Groen 2.Rode 3.Witte 4.Blauw 5.Gele");
            slag = CheckConsole(1, 5);
            Console.WriteLine("Hoeveel geld wil je inzetten?");
            bet = CheckConsole(1, money);
            money -= bet;
            SlagRace();
        }

        private static void WinnerChek()
        {
            if (money > record) { record = money; }
            if (slag == winner)
            {
                money += bet * 5;
                bet = 0;
                Console.WriteLine("     Je hebt gewonnen!");

                Thread.Sleep(2500);
                Console.Clear();
                Save();

            }

            else if (slag != winner)
            {
                bet = 0;
                Console.WriteLine("     Je hebt verloren!");
                Thread.Sleep(2500);
                Save();
                if (money == 0)
                {
                    Console.WriteLine("          GAME OVER");
                    GameOver();
                }
            }
        }

        private static void SlagRace()
        {
            List<int> distance = new List<int>() { 0, 0, 0, 0, 0 };
            Console.Clear();

            List<List<string>> drawslagEndinggY = new List<List<string>>();
            for (int i = 0; i < 5; i++)
            {
                List<string> g = new List<string>();
                foreach (string s in drawslagEnd)
                {
                    g.Add(s);
                }

                drawslagEndinggY.Add(g);
            }
            List<List<string>> drawslagBeginningY = new List<List<string>>();
            for (int i = 0; i < 5; i++)
            {
                List<string> g = new List<string>();
                drawslagBeginningY.Add(g);
            }
            List<int> color = new List<int>() { 10, 12, 15, 9, 14 };
            while (distance[distance.IndexOf(distance.Max())] < 38)
            {
                List<int> move = new List<int>() { rnd.Next(1, 11), rnd.Next(1, 11), rnd.Next(1, 11), rnd.Next(1, 11), rnd.Next(1, 11) };
                Console.Clear();
                for (int i = 0; i < 5; i++)
                {
                    if (distance[i] == 38)
                    {
                        break;
                    }
                    distance[i] += DrawSlag(color[i], move[i], drawslagBeginningY[i], drawslagEndinggY[i]);
                }
                Thread.Sleep(100);

            }
            winner = distance.IndexOf(distance.Max()) + 1;
            Console.ResetColor();
            WinnerChek();
        }
        private static int DrawSlag(int i, int n, List<string> beginning, List<string> ending)
        {
            int move = 0;
            Console.ForegroundColor = colors[i];
            foreach (string s in drawslagMidle)
            {
                Console.Write(string.Join("", beginning) + s + string.Join("", ending));
                Console.ResetColor();
                Console.WriteLine(finnish);
                Console.ForegroundColor = colors[i];
            }

            if (n == 1 & ending.Count > 0)
            {
                beginning.Add(" ");
                ending.RemoveAt(0);
                move++;
                if (soundOn == true)
                {
                    sMusic.Play();
                }
            }
            return move;
        }
        private static int CheckConsole(int iMin, int iMax)
        {
            string s = Console.ReadLine();
            bool b = Int32.TryParse(s, out int i);
            if (b == true)
            {
                if (Convert.ToInt32(s) > iMax | Convert.ToInt32(s) < iMin)
                {
                    b = false;
                }
            }
            while (b == false)
            {
                Console.WriteLine("Verkeerde keuze!");
                s = Console.ReadLine();
                b = Int32.TryParse(s, out i);
                if (b == true)
                {
                    if (Convert.ToInt32(s) > iMax | Convert.ToInt32(s) < iMin)
                    {
                        b = false;
                    }
                }
            }
            return Convert.ToInt32(s);
        }
        private static void GameOver()
        {
            Console.Write("Wil je score opslaan? score is: " + record + " \n1.Ja 2.Nee: ");
            int i = CheckConsole(1, 2);
            if (i == 1)
            {
                Console.Write("Jouw Naam: ");
                string s = Console.ReadLine();
                StreamWriter sw = new StreamWriter(save, true, Encoding.ASCII);
                sw.WriteLine($"{s}\n{record}");
                sw.Close();
            }
            Console.Write("Wil je opniew spelen? \n1.Ja 2.Nee: ");
            i = CheckConsole(1, 2);
            if (i == 1) { MainMenu(); money = 500; }
            else { Exit(); }
        }
        private static void LeaderBord()
        {
            StreamReader sr = File.OpenText(save);
            string s = "";
            List<int> saveMoney = new List<int>();
            List<string> saveName = new List<string>();
            List<string> resolt = new List<string>();
            int d = 2;
            while ((s = sr.ReadLine()) != null)
            {
                if (d % 2 == 0)
                {
                    saveName.Add(s);
                }
                if ((d % 2) > 0)
                {
                    saveMoney.Add(Convert.ToInt32(s));
                }
                d++;
            }
            for (int i = 0; i < 10; i++)
            {
                int j = 0;
                if (j <= saveMoney.Count() - 1)
                {
                    j = saveMoney.IndexOf(saveMoney.Max());
                    resolt.Add(saveName[j] + " " + saveMoney[j]);
                    saveName.RemoveAt(saveMoney.IndexOf(saveMoney.Max()));
                    saveMoney.RemoveAt(saveMoney.IndexOf(saveMoney.Max()));
                }
                if (i <= resolt.Count - 1) { Console.WriteLine(resolt[i]); }
            }
            sr.Close();
            Console.WriteLine("Druk op een willekeurige toets om terug te gaan in het menu");
            Console.ReadLine();
            MainMenu();
        }
        private static void Save()
        {
            List<string> list = new List<string>();
            list.Add(Convert.ToString(money));
            File.WriteAllLines(saveM, list);
            if (toExit == false)
            {
                MainMenu();
            }

        }
        private static void PlayBMusic( /*https://stackoverflow.com/questions/12535722/what-is-the-best-way-to-implement-a-timer allen parametres "object source, ElapsedEventArgs e"*/ object source, ElapsedEventArgs e)
        {
            if (musicOn == true)
            {
                bMusic.Play();
            }

        }
    }
}
