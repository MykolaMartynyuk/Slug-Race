﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SlugRace_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DispatcherTimer gameRun = new DispatcherTimer();
        public static System.Timers.Timer playSound = new System.Timers.Timer();
        private int count = 0;
        public static Random rnd = new Random();
        private static List<Rectangle> rectsSlag = new List<Rectangle>();
        private static List<Control> menu = new List<Control>();
        private static int winner;
        public static string save = @"save.txt";
        public static string saveM = @"saveM.txt";
        public static SoundPlayer sMusic = new SoundPlayer(@"sound\slagmove.wav");
        public static SoundPlayer bMusic = new SoundPlayer(@"sound\backgroundmusic.wav");
        public static bool musicOn = true;
        public static bool soundOn = true;
        public static int exitOrBack = 0;
        public static int money = 500;
        public static int bet;
        public static int slagChoose = 0;
        List<Control> menuBet = new List<Control>();


        public MainWindow()
        {
            playSound.Elapsed += new ElapsedEventHandler(PlayBMusic);
            playSound.Interval = 14500;
            bMusic.Play();
            if (musicOn == true)
            {
                playSound.Start();
            }
            StreamReader sr = File.OpenText(saveM);
            string s;
            while ((s = sr.ReadLine()) != null)
            {
                money = Convert.ToInt32(s);
                sr.ReadToEnd();
                break;
            }
            sr.Close();
            if (money == 0) { money = 500; }
            InitializeComponent();
            cbSlags.Background = Brushes.Green;
            txtScores.IsEnabled = false;
            rectsSlag = new List<Rectangle>() { slagG, slagR, slagW, slagB, slagY };
            menu = new List<Control>() { btnStart, btnScorebord, btnOpties, btnEXIT };
            menuBet = new List<Control>() { btnBevestigen, cbSlags, txtBet, lblBetMoney, lblBetSlag, lblBet };
            gameRun.Interval = TimeSpan.FromMilliseconds(1);

            if (!File.Exists(save))
            {
                File.Create(save);
            }
            if (!File.Exists(saveM))
            {
                File.Create(saveM);
            }
            lblMoney.Content = money + "$";
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            foreach (Control control in menuBet)
            {
                control.Visibility = Visibility.Visible;
                control.IsEnabled = true;
            }


            gameRun.Tick += Race;
        }
        private void Race(object sender, EventArgs e)
        {
            count = 5;
            MenuUp(menuBet);
            MenuUp(menu);
            slagUP(rectsSlag);
            slagRun(rectsSlag);


        }
        private void MenuUp(List<Control> c)
        {

            if (btnEXIT.Margin.Bottom < 810)
            {

                for (int i = 0; i < c.Count; i++)
                {
                    Thickness marging = c[i].Margin;
                    marging.Top -= count;
                    marging.Bottom += count;
                    c[i].Margin = marging;
                }
            }
        }
        private void slagRun(List<Rectangle> s)
        {

            Thickness marging = new Thickness();
            if (rtGameField.Margin.Top == 0)
            {
                foreach (Control control in menuBet)
                {
                    control.Visibility = Visibility.Hidden;
                    control.IsEnabled = false;
                }

                for (int i = 0; i < 5; i++)
                {
                    marging = s[i].Margin;
                    int j = rnd.Next(0,3);

                    marging.Right -= j;
                    if (rnd.Next(0,25) == 2) { sMusic.Play(); }

                    s[i].Margin = marging;
                    if (marging.Right == 100)
                    {
                        winner = i;
                        gameRun.Stop();
                        lblGameResolt.Visibility = Visibility.Visible;
                        if (winner == slagChoose)
                        {
                            lblGameResolt.Content = "Gefeliciteerd!";
                            money += bet * 5;
                            lblMoney.Content = money + "$";




                        }
                        else
                        {

                            lblGameResolt.Content = "Spijt!";




                        }
                        Save();
                        gameRun.Tick -= Race;
                        gameRun.Tick += Reset;

                        gameRun.Start();
                        Thread.Sleep(1000);
                    }
                }
            }
        }
        private void slagUP(List<Rectangle> s)
        {

            if (rtGameField.Margin.Top != 0)
            {


                Thickness margingF = rtGameField.Margin;
                margingF.Top -= count;
                rtGameField.Margin = margingF;
                for (int i = 0; i < 5; i++)
                {
                    Thickness marging = s[i].Margin;
                    marging.Top -= count;
                    s[i].Margin = marging;
                }
            }
        }
        private void slagDown(List<Rectangle> s)
        {
            if (rtGameField.Margin.Top < 800)
            {


                Thickness margingF = rtGameField.Margin;
                margingF.Top += count;
                rtGameField.Margin = margingF;
                for (int i = 0; i < 5; i++)
                {
                    Thickness marging = s[i].Margin;
                    marging.Top += count;
                    s[i].Margin = marging;
                }
            }
            if (rtGameField.Margin.Top == 800)
            {
                gameRun.Stop();
                gameRun.Tick -= Reset;
            }
        }
        private void Reset(object sender, EventArgs e)
        {
            MenuDown(menu);
            MenuDown(menuBet);
            slagDown(rectsSlag);

        }
        private void btnScorebord_Click(object sender, RoutedEventArgs e)
        {
            btnAddScore.Visibility = Visibility.Visible;
            btnAddScore.IsEnabled = true;
            txtRecordName.Visibility = Visibility.Visible;
            txtRecordName.IsEnabled = true;
            for (int i = 0; i < 3; i++)
            {
                menu[i].IsEnabled = false;
                menu[i].Visibility = Visibility.Hidden;
            }
            exitOrBack = 1;
            txtScores.Visibility = Visibility.Visible;
            btnEXIT.Content = "MENU";
            btnEXIT.Background = Brushes.Gray;
            StreamReader sr = File.OpenText(save);
            string s = "";
            List<int> names = new List<int>();
            List<string> points = new List<string>();
            List<string> nameAndScore = new List<string>();
            int d = 2;
            while ((s = sr.ReadLine()) != null)
            {
                if (d % 2 == 0)
                {
                    points.Add(s);
                }
                if ((d % 2) > 0)
                {
                    names.Add(Convert.ToInt32(s));
                }
                d++;
            }
            txtScores.Text = string.Empty;
            for (int i = 0; i < 5; i++)
            {
                int j = 0;
                if (0 <= names.Count() - 1)
                {
                    j = names.IndexOf(names.Max());
                    nameAndScore.Add(points[j] + " " + names[j]);
                    points.RemoveAt(names.IndexOf(names.Max()));
                    names.RemoveAt(names.IndexOf(names.Max()));
                }

                if (i <= nameAndScore.Count - 1) { txtScores.Text += nameAndScore[i] + "\n"; }
            }
            sr.Close();

        }

        private void btnOpties_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < 3; i++)
            {
                menu[i].IsEnabled = false;
                menu[i].Visibility = Visibility.Hidden;
            }
            btnEXIT.Content = "MENU";
            btnEXIT.Background = Brushes.Gray;
            exitOrBack = 1;
            lblOption.Visibility = Visibility.Visible;
            rbSoundOn.IsEnabled = true;
            rbSoundOn.Visibility = Visibility.Visible;
            rbSoundOff.IsEnabled = true;
            rbSoundOff.Visibility = Visibility.Visible;
        }

        private void btnEXIT_Click(object sender, RoutedEventArgs e)
        {
            if (exitOrBack == 0)
            {
                this.Close();
            }
            else if (exitOrBack == 1)
            {
                for (int i = 0; i < 3; i++)
                {
                    menu[i].IsEnabled = true;
                    menu[i].Visibility = Visibility.Visible;
                }
                btnEXIT.Content = "AFSLUITEN";
                btnEXIT.Background = Brushes.Red;
                txtScores.Visibility = Visibility.Hidden;
                exitOrBack = 0;
                lblOption.Visibility = Visibility.Hidden;
                rbSoundOn.IsEnabled = false;
                rbSoundOn.Visibility = Visibility.Hidden;
                rbSoundOff.IsEnabled = false;
                rbSoundOff.Visibility = Visibility.Hidden;
                btnAddScore.Visibility = Visibility.Hidden;
                btnAddScore.IsEnabled = false;
                txtRecordName.Visibility = Visibility.Hidden;
                txtRecordName.IsEnabled = false;
            }
        }
        private static void PlayBMusic( /*https://stackoverflow.com/questions/12535722/what-is-the-best-way-to-implement-a-timer allen parametres "object source, ElapsedEventArgs e"*/ object source, ElapsedEventArgs e)
        {
            if (musicOn == true)
            {
                bMusic.Play();
            }

        }

        private void rbSoundOn_Checked(object sender, RoutedEventArgs e)
        {
            musicOn = true;
            bMusic.Play();
            playSound.Start();
        }

        private void rbSoundOff_Checked(object sender, RoutedEventArgs e)
        {
            musicOn &= false;
            musicOn = false;
            playSound.Stop();
            bMusic.Stop();
        }

        private void btnBevestigen_Click(object sender, RoutedEventArgs e)
        {
            string s = txtBet.Text;
            bool b = int.TryParse(s, out int i);
            foreach (Rectangle rect in rectsSlag)
            {
                Thickness marging = rect.Margin;

                marging.Right = 657;
                rect.Margin = marging;
            }
            if (b == false)
            {
                lblFout.Visibility = Visibility.Visible;
                return;

            }
            if (Convert.ToInt32(s) > money | Convert.ToInt32(s) <= 0)
            {
                return;
            }

            lblFout.Visibility = Visibility.Hidden;
            bet = Convert.ToInt32(s);
            money -= bet;
            lblMoney.Content = money + "$";
            slagChoose = cbSlags.SelectedIndex;
            gameRun.Start();
        }
        private void MenuDown(List<Control> c)
        {
            if (btnEXIT.Margin.Bottom > 0)
            {

                for (int i = 0; i < c.Count; i++)
                {
                    Thickness marging = c[i].Margin;
                    marging.Top += count;
                    marging.Bottom -= count;
                    c[i].Margin = marging;
                }
            }
            if (btnEXIT.Margin.Bottom == 200)
            {
                lblGameResolt.Content = "";
                bMusic.Play();
            }
        }

        private void btnAddScore_Click(object sender, RoutedEventArgs e)
        {
            string s = txtRecordName.Text;
            StreamWriter sw = new StreamWriter(save, true, Encoding.ASCII);
            sw.WriteLine($"{s}\n{money}");
            sw.Close();
            StreamReader sr = File.OpenText(save);
            s = "";
            List<int> names = new List<int>();
            List<string> points = new List<string>();
            List<string> nameAndScore = new List<string>();
            int d = 2;
            while ((s = sr.ReadLine()) != null)
            {
                if (d % 2 == 0)
                {
                    points.Add(s);
                }
                if ((d % 2) > 0)
                {
                    names.Add(Convert.ToInt32(s));
                }
                d++;
            }
            txtScores.Text = string.Empty;
            for (int i = 0; i < 5; i++)
            {
                int j = 0;
                if (0 <= names.Count() - 1)
                {
                    j = names.IndexOf(names.Max());
                    nameAndScore.Add(points[j] + " " + names[j]);
                    points.RemoveAt(names.IndexOf(names.Max()));
                    names.RemoveAt(names.IndexOf(names.Max()));
                }

                if (i <= nameAndScore.Count - 1) { txtScores.Text += nameAndScore[i] + "\n"; }
            }
            sr.Close();
        }

        private void txtRecordName_MouseEnter(object sender, MouseEventArgs e)
        {
            if (txtRecordName.Text == "Jouw naam...")
            {
                txtRecordName.Text = "";
                txtRecordName.Foreground.Opacity = 1;
            }

        }
        private void Save()
        {
            List<string> list = new List<string>();
            list.Add(Convert.ToString(money));
            File.WriteAllLines(saveM, list);


        }
    }

}
